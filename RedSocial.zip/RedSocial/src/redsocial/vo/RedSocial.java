/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redsocial.vo;

/**
 *
 * @author Andres Felipe Bernal
 */
public class RedSocial {
    private int id_RedSocial;
    private String nombre;

    public RedSocial( String nombre) {
        this.nombre = nombre;
    }

       
    public int getId_RedSocial() {
        return id_RedSocial;
    }

    public void setId_RedSocial(int id_RedSocial) {
        this.id_RedSocial = id_RedSocial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}