/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package redsocial;

import redsocial.dao.RedSocialDAO;
import redsocial.vo.RedSocial;

/**
 *
 * @author andresfelipe
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RedSocialDAO dao = new RedSocialDAO();
        RedSocial red = new RedSocial("red1");
        dao.insert(red);

    }
    
}
